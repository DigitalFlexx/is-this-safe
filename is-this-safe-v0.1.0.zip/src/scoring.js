/**
 * Trust score model for Is This Safe? — Extension Auditor
 *
 * Every extension starts at 100. Penalties are subtracted and the
 * result is clamped to [0, 100]. Edit WEIGHTS to tune the model.
 */

const WEIGHTS = {
  allUrls: {
    penalty: 35,
    reason: 'Can read and change data on every website you visit — including passwords and what you type.',
  },
  sensitiveHost: {
    penaltyEach: 10,
    maxPenalty: 25,
    reason: (count) =>
      `Has access to ${count} sensitive website${count > 1 ? 's' : ''} (banking, email, or social media).`,
  },
  tabs: {
    penalty: 10,
    reason: 'Can see the addresses and titles of all your open tabs.',
  },
  webRequest: {
    penalty: 20,
    reason: 'Can monitor and modify your network traffic as it passes through your browser.',
  },
  webRequestBlocking: {
    penalty: 20,
    reason: 'Can block and modify your network requests in real time.',
  },
  cookies: {
    penalty: 15,
    reason: 'Can read your login cookies, potentially accessing accounts on sites it can reach.',
  },
  history: {
    penalty: 15,
    reason: 'Can read your full browsing history.',
  },
  scripting: {
    penalty: 15,
    reason: 'Can inject and run its own code in web pages.',
  },
  clipboardRead: {
    penalty: 10,
    reason: 'Can read whatever you have copied to your clipboard.',
  },
  nativeMessaging: {
    penalty: 15,
    reason: 'Can communicate with a program installed on your computer.',
  },
  debugger: {
    penalty: 25,
    reason: "Has access to Chrome's debugging API — can inspect all browser activity.",
  },
  sideload: {
    penalty: 20,
    reason: 'Not installed from the Chrome Web Store — the source cannot be verified.',
  },
};

// Each regex matches a category of sensitive domains.
// One match per category counts as one penalty tick (capped at maxPenalty total).
const SENSITIVE_HOST_PATTERNS = [
  /google\.com|gmail\.com/,
  /facebook\.com|instagram\.com|threads\.net/,
  /twitter\.com|\.x\.com/,
  /linkedin\.com/,
  /chase\.com|wellsfargo\.com|bankofamerica\.com|citibank\.com|usbank\.com/,
  /paypal\.com|venmo\.com|cashapp\.com/,
  /amazon\.com/,
  /apple\.com|icloud\.com/,
  /microsoft\.com|outlook\.com|live\.com|office\.com/,
  /github\.com|gitlab\.com/,
  /dropbox\.com|onedrive\.live\.com/,
  /slack\.com|discord\.com/,
  /openai\.com/,
  /claude\.ai/,
];

/**
 * @param {object} ext - chrome.management.ExtensionInfo
 * @returns {{ score: number, verdict: string, verdictClass: string, reasons: string[] }}
 */
function scoreExtension(ext) {
  let score = 100;
  const reasons = [];

  const permissions     = ext.permissions     || [];
  const hostPermissions = ext.hostPermissions || [];

  // ── Host access ──────────────────────────────────────────────────────────
  const hasAllUrls = hostPermissions.some(
    (h) =>
      h === '<all_urls>' ||
      h === '*://*/*' ||
      h === 'http://*/*' ||
      h === 'https://*/*' ||
      h === 'ftp://*/*'
  );

  if (hasAllUrls) {
    score -= WEIGHTS.allUrls.penalty;
    reasons.push(WEIGHTS.allUrls.reason);
  } else {
    let sensitivePenalty = 0;
    let sensitiveCount   = 0;
    for (const pattern of SENSITIVE_HOST_PATTERNS) {
      if (hostPermissions.some((h) => pattern.test(h))) {
        sensitiveCount++;
        sensitivePenalty = Math.min(
          sensitivePenalty + WEIGHTS.sensitiveHost.penaltyEach,
          WEIGHTS.sensitiveHost.maxPenalty
        );
      }
    }
    if (sensitiveCount > 0) {
      score -= sensitivePenalty;
      reasons.push(WEIGHTS.sensitiveHost.reason(sensitiveCount));
    }
  }

  // ── Per-permission penalties ──────────────────────────────────────────────
  const PERM_CHECKS = [
    ['tabs',               WEIGHTS.tabs],
    ['webRequest',         WEIGHTS.webRequest],
    ['webRequestBlocking', WEIGHTS.webRequestBlocking],
    ['cookies',            WEIGHTS.cookies],
    ['history',            WEIGHTS.history],
    ['scripting',          WEIGHTS.scripting],
    ['clipboardRead',      WEIGHTS.clipboardRead],
    ['nativeMessaging',    WEIGHTS.nativeMessaging],
    ['debugger',           WEIGHTS.debugger],
  ];

  for (const [key, w] of PERM_CHECKS) {
    if (permissions.includes(key)) {
      score -= w.penalty;
      reasons.push(w.reason);
    }
  }

  // ── Install source ────────────────────────────────────────────────────────
  if (['development', 'sideload', 'other'].includes(ext.installType)) {
    score -= WEIGHTS.sideload.penalty;
    reasons.push(WEIGHTS.sideload.reason);
  }

  // ── Clamp + verdict ───────────────────────────────────────────────────────
  score = Math.max(0, Math.min(100, score));

  let verdict, verdictClass;
  if (score >= 80) {
    verdict      = 'Safe';
    verdictClass = 'safe';
  } else if (score >= 50) {
    verdict      = 'Caution';
    verdictClass = 'caution';
  } else {
    verdict      = 'High Risk';
    verdictClass = 'high-risk';
  }

  return { score, verdict, verdictClass, reasons };
}

// CommonJS export for Node-based test runners; no-op in browser/service worker
if (typeof module !== 'undefined') {
  module.exports = { scoreExtension, WEIGHTS, SENSITIVE_HOST_PATTERNS };
}
