/**
 * Snapshot persistence helpers for background monitoring.
 * Snapshots capture each extension's permissions so the service worker
 * can detect changes between events.
 */

const SNAPSHOT_KEY = 'ext_snapshot_v1';

/**
 * Persist a snapshot of the provided extensions array.
 * @param {chrome.management.ExtensionInfo[]} extensions
 */
async function saveSnapshot(extensions) {
  const snapshot = {};
  for (const ext of extensions) {
    snapshot[ext.id] = {
      name:            ext.name,
      permissions:     ext.permissions     || [],
      hostPermissions: ext.hostPermissions || [],
      enabled:         ext.enabled,
      installType:     ext.installType,
      version:         ext.version,
      savedAt:         Date.now(),
    };
  }
  await chrome.storage.local.set({ [SNAPSHOT_KEY]: snapshot });
  return snapshot;
}

/**
 * Load the last-saved snapshot.
 * @returns {Promise<object>} map of extension id → saved info
 */
async function loadSnapshot() {
  const result = await chrome.storage.local.get(SNAPSHOT_KEY);
  return result[SNAPSHOT_KEY] || {};
}

// Permissions that are significant enough to alert on if newly granted.
const DANGEROUS_PERMS = new Set([
  '<all_urls>', '*://*/*', 'http://*/*', 'https://*/*',
  'webRequest', 'webRequestBlocking',
  'cookies', 'history', 'debugger', 'nativeMessaging',
  'clipboardRead', 'scripting',
]);

/**
 * Compare a stored snapshot against a fresh extension list.
 *
 * @param {object} oldSnap - previous snapshot (from loadSnapshot)
 * @param {chrome.management.ExtensionInfo[]} newExts - current extension list
 * @returns {{ newInstalls: object[], gainedDangerousPerms: object[] }}
 */
function diffSnapshots(oldSnap, newExts) {
  const newInstalls         = [];
  const gainedDangerousPerms = [];

  for (const ext of newExts) {
    const prev = oldSnap[ext.id];

    if (!prev) {
      newInstalls.push(ext);
      continue;
    }

    const prevPerms = new Set([...(prev.permissions || []), ...(prev.hostPermissions || [])]);
    const currPerms = [...(ext.permissions || []), ...(ext.hostPermissions || [])];
    const gained    = currPerms.filter((p) => !prevPerms.has(p) && DANGEROUS_PERMS.has(p));

    if (gained.length > 0) {
      gainedDangerousPerms.push({ ext, gained });
    }
  }

  return { newInstalls, gainedDangerousPerms };
}
