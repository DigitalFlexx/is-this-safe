/**
 * Plain-English descriptions for Chrome extension permission identifiers.
 * Used in the expanded card view to explain what each permission does.
 * Extend this map as new permissions are encountered.
 */
const PERMISSION_DESCRIPTIONS = {
  // ── Host access ──────────────────────────────────────────────────────────
  '<all_urls>':   'Read and change everything on every website you visit.',
  '*://*/*':      'Read and change everything on every website you visit.',
  'http://*/*':   'Read and change everything on every HTTP website you visit.',
  'https://*/*':  'Read and change everything on every HTTPS website you visit.',

  // ── High-risk APIs ────────────────────────────────────────────────────────
  'tabs':                'See the addresses and titles of all your open tabs.',
  'webRequest':          'Monitor and inspect your network traffic.',
  'webRequestBlocking':  'Block and modify your network requests before they are sent.',
  'cookies':             'Read your login cookies for websites it can access.',
  'history':             'Read your full browsing history.',
  'scripting':           'Inject and run code in web pages.',
  'clipboardRead':       'Read whatever you copy to your clipboard.',
  'nativeMessaging':     'Communicate with a program installed on your computer.',
  'debugger':            "Inspect all browser activity via Chrome's debug API.",
  'privacy':             'Change your browser privacy settings.',
  'proxy':               'Control your internet connection and routing.',
  'browsingData':        'Delete your browsing history, cookies, and cached files.',
  'pageCapture':         'Save entire web pages including their content.',
  'geolocation':         'Access your physical location.',
  'identity':            'Request access to your Google or other sign-in accounts.',
  'contentSettings':     'Change site-level permissions such as camera and microphone.',
  'processes':           "Monitor Chrome's internal processes.",
  'downloads':           'See and manage your file downloads.',
  'downloads.open':      'Open files you have downloaded.',
  'management':          'See and control other installed extensions.',
  'sessions':            'Read recently closed tabs and browser windows.',

  // ── Declarative network ───────────────────────────────────────────────────
  'declarativeNetRequest':         'Block or redirect network requests using predefined rules.',
  'declarativeNetRequestFeedback': 'See which network requests were blocked or redirected.',

  // ── Moderate-risk ─────────────────────────────────────────────────────────
  'bookmarks':      'Read and modify your bookmarks.',
  'topSites':       'See your most frequently visited websites.',
  'readingList':    'Access your Reading List.',
  'webNavigation':  'Be notified whenever you navigate to a new page.',
  'system.storage': 'Detect when external storage devices are connected or removed.',

  // ── Usually low-risk ─────────────────────────────────────────────────────
  'storage':           'Store data locally in your browser.',
  'unlimitedStorage':  'Store an unlimited amount of data locally in your browser.',
  'notifications':     'Send you browser notifications.',
  'contextMenus':      'Add items to your right-click context menu.',
  'alarms':            'Run code on a schedule.',
  'activeTab':         'Access the current tab temporarily when you click the extension.',
  'background':        'Run in the background even when the extension popup is closed.',
  'idle':              'Detect when your computer is idle.',
  'power':             'Prevent your screen from going to sleep.',
  'offscreen':         'Use a hidden document for background audio or processing.',
  'sidePanel':         'Display content in the browser side panel.',
  'tts':               'Use text-to-speech to read content aloud.',
};
