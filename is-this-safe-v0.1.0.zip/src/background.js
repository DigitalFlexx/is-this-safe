/**
 * Service worker — background monitoring for Is This Safe?
 *
 * Responsibilities:
 *  - Badge the toolbar icon with the count of High Risk extensions
 *  - Diff extension snapshots on install/uninstall/enable events
 *  - Fire notifications when a new high-risk extension is detected (Pro)
 */

importScripts('scoring.js', 'storage.js');

// ── Pro gate (stub — wire ExtensionPay here later) ────────────────────────────
function isPro() {
  return false; // TODO: replace with ExtensionPay license check
}

// ── Badge ─────────────────────────────────────────────────────────────────────
async function updateBadge() {
  try {
    const all   = await chrome.management.getAll();
    const ownId = chrome.runtime.id;

    const highRiskCount = all
      .filter((e) => e.id !== ownId && e.type === 'extension')
      .map((e)  => scoreExtension(e))
      .filter((r) => r.verdictClass === 'high-risk')
      .length;

    if (highRiskCount > 0) {
      chrome.action.setBadgeText({ text: String(highRiskCount) });
      chrome.action.setBadgeBackgroundColor({ color: '#dc2626' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  } catch (err) {
    console.error('[IsThisSafe] Badge update failed:', err);
  }
}

// ── Snapshot + diff + optional notifications ──────────────────────────────────
async function runMonitoring() {
  try {
    const all   = await chrome.management.getAll();
    const ownId = chrome.runtime.id;
    const exts  = all.filter((e) => e.id !== ownId && e.type === 'extension');

    const oldSnap = await loadSnapshot();
    const { newInstalls, gainedDangerousPerms } = diffSnapshots(oldSnap, exts);

    if (isPro()) {
      for (const ext of newInstalls) {
        const audit = scoreExtension(ext);
        if (audit.verdictClass === 'high-risk') {
          await fireNotification(
            'New high-risk extension installed',
            `"${ext.name}" ${audit.reasons[0]?.toLowerCase() ?? 'has high-risk permissions.'}`
          );
        }
      }

      for (const { ext, gained } of gainedDangerousPerms) {
        await fireNotification(
          'Extension gained new access',
          `"${ext.name}" now has: ${gained.join(', ')}.`
        );
      }
    }

    await saveSnapshot(exts);
  } catch (err) {
    console.error('[IsThisSafe] Monitoring error:', err);
  }
}

async function fireNotification(title, message) {
  return chrome.notifications.create({
    type:     'basic',
    iconUrl:  chrome.runtime.getURL('icons/48.png'),
    title:    `Is This Safe? — ${title}`,
    message,
    priority: 1,
  });
}

// ── Event listeners ───────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  await updateBadge();
  await runMonitoring();
});

chrome.runtime.onStartup.addListener(async () => {
  await updateBadge();
});

chrome.management.onInstalled.addListener(async () => {
  await updateBadge();
  await runMonitoring();
});

chrome.management.onUninstalled.addListener(async () => {
  await updateBadge();
  // Rebuild snapshot after removal so old ids don't linger
  const all   = await chrome.management.getAll();
  const ownId = chrome.runtime.id;
  await saveSnapshot(all.filter((e) => e.id !== ownId && e.type === 'extension'));
});

chrome.management.onEnabled.addListener(async () => {
  await updateBadge();
  await runMonitoring();
});

chrome.management.onDisabled.addListener(async () => {
  await updateBadge();
});
