(async function () {
  'use strict';

  const listEl      = document.getElementById('ext-list');
  const headlineEl  = document.getElementById('summary-headline');
  const subEl       = document.getElementById('summary-sub');
  const summaryIcon = document.getElementById('summary-icon');

  // ── Load & score ────────────────────────────────────────────────────────
  let audited;
  try {
    const all   = await chrome.management.getAll();
    const ownId = chrome.runtime.id;

    audited = all
      .filter((e) => e.id !== ownId && e.type === 'extension')
      .map((e)    => ({ ext: e, audit: scoreExtension(e) }))
      .sort((a, b) => a.audit.score - b.audit.score); // worst first
  } catch (err) {
    listEl.innerHTML = `<div id="loading">
      Error loading extensions. Try reopening this popup.
    </div>`;
    console.error('[IsThisSafe]', err);
    return;
  }

  // ── Summary bar ──────────────────────────────────────────────────────────
  const highRiskCount = audited.filter((a) => a.audit.verdictClass === 'high-risk').length;
  const cautionCount  = audited.filter((a) => a.audit.verdictClass === 'caution').length;
  const total         = audited.length;

  if (total === 0) {
    summaryIcon.textContent = '✅';
    headlineEl.textContent  = 'No extensions installed.';
    subEl.textContent       = 'Install some and reopen to audit them.';
  } else if (highRiskCount === 0 && cautionCount === 0) {
    summaryIcon.textContent = '✅';
    headlineEl.textContent  = `All ${total} extension${total !== 1 ? 's' : ''} look safe.`;
    subEl.textContent       = 'No high-risk or cautionary permissions detected.';
  } else {
    const riskyCount = highRiskCount + cautionCount;
    summaryIcon.textContent = highRiskCount > 0 ? '⚠️' : '🔶';
    headlineEl.textContent  =
      `${riskyCount} of your ${total} extension${total !== 1 ? 's' : ''} ${riskyCount === 1 ? 'needs' : 'need'} attention.`;
    const parts = [];
    if (highRiskCount > 0) parts.push(`${highRiskCount} high-risk`);
    if (cautionCount  > 0) parts.push(`${cautionCount} caution`);
    subEl.textContent = parts.join(', ') + ' — see below.';
  }

  // ── Extension list ───────────────────────────────────────────────────────
  listEl.innerHTML = '';

  if (audited.length === 0) {
    listEl.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🛡️</div>
        <div class="empty-title">You're all clear!</div>
        <div class="empty-sub">No extensions installed (other than this one).</div>
      </div>
    `;
    return;
  }

  for (const { ext, audit } of audited) {
    listEl.appendChild(buildCard(ext, audit));
  }

  // ── Card builder ──────────────────────────────────────────────────────────
  function buildCard(ext, audit) {
    const isDisabled = !ext.enabled;
    const tagline    = getTagline(audit, isDisabled);

    // ── Head ──
    const head = document.createElement('div');
    head.className = 'card-head';

    const img = document.createElement('img');
    img.className = 'ext-icon';
    img.src       = getBestIcon(ext);
    img.alt       = '';
    img.onerror   = () => { img.src = fallbackIcon(); };

    const meta = document.createElement('div');
    meta.className = 'ext-meta';

    const nameRow = document.createElement('div');
    nameRow.className = 'ext-name';
    nameRow.appendChild(document.createTextNode(ext.name));
    if (isDisabled) {
      const chip = document.createElement('span');
      chip.className   = 'disabled-chip';
      chip.textContent = 'Disabled';
      nameRow.appendChild(chip);
    }

    const tag = document.createElement('div');
    tag.className   = 'ext-tagline';
    tag.textContent = tagline;

    meta.appendChild(nameRow);
    meta.appendChild(tag);

    const pill = document.createElement('div');
    pill.className   = `score-pill ${audit.verdictClass}`;
    pill.textContent = audit.score;

    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'toggle-btn';
    toggleBtn.setAttribute('aria-expanded', 'false');
    toggleBtn.setAttribute('title', 'Show details');
    toggleBtn.textContent = '▾';

    head.appendChild(img);
    head.appendChild(meta);
    head.appendChild(pill);
    head.appendChild(toggleBtn);

    // ── Body ──
    const body = document.createElement('div');
    body.className = 'card-body';
    body.hidden    = true;

    if (audit.reasons.length > 0) {
      const label = document.createElement('div');
      label.className   = 'reasons-label';
      label.textContent = 'Why this score';

      const ul = document.createElement('ul');
      ul.className = 'reasons-list';
      for (const reason of audit.reasons) {
        const li = document.createElement('li');
        li.textContent = reason;
        ul.appendChild(li);
      }
      body.appendChild(label);
      body.appendChild(ul);
    } else {
      const ok = document.createElement('p');
      ok.className   = 'no-issues';
      ok.textContent = 'No concerning permissions found.';
      body.appendChild(ok);
    }

    const manageBtn = document.createElement('button');
    manageBtn.className   = 'manage-btn';
    manageBtn.textContent = 'Manage Extension →';
    manageBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.tabs.create({ url: `chrome://extensions/?id=${ext.id}` });
      window.close();
    });
    body.appendChild(manageBtn);

    // ── Toggle ──
    function toggle() {
      const isOpen = !body.hidden;
      body.hidden             = isOpen;
      toggleBtn.textContent   = isOpen ? '▾' : '▴';
      toggleBtn.setAttribute('aria-expanded', String(!isOpen));
    }

    head.addEventListener('click', toggle);

    // ── Assemble ──
    const card = document.createElement('div');
    card.className = `card ${audit.verdictClass}`;
    card.appendChild(head);
    card.appendChild(body);
    return card;
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  function getTagline(audit, isDisabled) {
    if (isDisabled)                           return 'Disabled — not actively running';
    if (audit.verdictClass === 'safe')        return 'Limited access — looks safe';
    if (audit.verdictClass === 'caution')     return 'Some permissions worth reviewing';
    /* high-risk */                           return 'High access to your browser and data';
  }

  function getBestIcon(ext) {
    if (!ext.icons || ext.icons.length === 0) return fallbackIcon();
    const sorted = [...ext.icons].sort((a, b) => a.size - b.size);
    const icon   = sorted.find((i) => i.size >= 32) || sorted[sorted.length - 1];
    return icon.url;
  }

  function fallbackIcon() {
    // Grey rounded-rect with horizontal lines (generic extension shape)
    return (
      "data:image/svg+xml," +
      encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">' +
        '<rect width="32" height="32" rx="7" fill="#f3f4f6"/>' +
        '<rect x="9" y="10" width="14" height="3" rx="1.5" fill="#d1d5db"/>' +
        '<rect x="9" y="15" width="14" height="3" rx="1.5" fill="#d1d5db"/>' +
        '<rect x="9" y="20" width="9"  height="3" rx="1.5" fill="#d1d5db"/>' +
        '</svg>'
      )
    );
  }
})();
